import numpy as np
import os
from joblib import Parallel, delayed
from numba import njit

NUM_SAMPLES = 10000
VECTOR_SIZE = 2 ** 16
R = 5
MOD_LIST = [43, 47, 53]
OUTPUT_DIR = "E:/diploma/arx_gost_allkeys"
NUM_JOBS = 12

@njit
def rol16(x, r):
    return ((x << r) | (x >> (16 - r))) & 0xFFFF

@njit
def arx_gost_round(x, y, k):
    yk = (y + k) & 0xFFFF
    return y, x ^ rol16(yk, R)

def process_key_chunk(keys, modN, num_samples, vector_size):
    table = np.zeros((modN * modN, modN), dtype=np.float64)
    counts = np.zeros(modN * modN, dtype=np.int64)
    xs = np.random.randint(0, vector_size, size=num_samples)
    ys = np.random.randint(0, vector_size, size=num_samples)

    for k in keys:
        for i in range(num_samples):
            x, y = xs[i], ys[i]
            _, z = arx_gost_round(x, y, k)
            x_mod = x % modN
            y_mod = y % modN
            z_mod = z % modN
            idx = x_mod * modN + y_mod
            table[idx, z_mod] += 1
            counts[idx] += 1

    return table, counts

def write_table(path, table, modN):
    col_width = 9
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"\n=== ARX-GOST (mod {modN}), усреднено по всім ключам k ∈ [0..65535] ===\n")
        header = " " * 6 + "".join(f"{z}".center(col_width) for z in range(modN))
        f.write(header + "\n")
        for row_idx, row in enumerate(table):
            x_class = row_idx // modN
            y_class = row_idx % modN
            row_str = f"({x_class},{y_class}) ".ljust(6)
            row_str += "".join(f"{v:>{col_width}.4f}" for v in row)
            f.write(row_str + "\n")

def process_modN(modN):
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    all_keys = np.arange(VECTOR_SIZE)
    chunks = np.array_split(all_keys, NUM_JOBS)

    results = Parallel(n_jobs=NUM_JOBS)(
        delayed(process_key_chunk)(chunk, modN, NUM_SAMPLES, VECTOR_SIZE) for chunk in chunks
    )

    final_table = np.zeros((modN * modN, modN), dtype=np.float64)
    final_counts = np.zeros(modN * modN, dtype=np.int64)

    for table, counts in results:
        final_table += table
        final_counts += counts

    for i in range(len(final_counts)):
        if final_counts[i] > 0:
            final_table[i, :] /= final_counts[i]

    path = os.path.join(OUTPUT_DIR, f"modN_{modN}.txt")
    write_table(path, final_table, modN)

if __name__ == "__main__":
    for modN in MOD_LIST:
        process_modN(modN)