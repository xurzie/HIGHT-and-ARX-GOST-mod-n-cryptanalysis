import numpy as np
import os

def rol8(x, r):
    return ((x << r) | (x >> (8 - r))) & 0xFF

def F0(x):
    return rol8(x, 1) ^ rol8(x, 2) ^ rol8(x, 7)

def F1(x):
    return rol8(x, 3) ^ rol8(x, 4) ^ rol8(x, 6)

def A_k(x, y, k):
    return ((x + F0(y ^ k)) % 256, y)

def B_k(x, y, k):
    return (x ^ F1((y + k) % 256), y)

def build_transition_table_key_class(block_func, modN, key_class):
    table = np.zeros((modN * modN, modN), dtype=np.float64)
    counts = np.zeros(modN * modN, dtype=np.int64)

    for x in range(256):
        for y in range(256):
            x_mod = x % modN
            y_mod = y % modN
            idx_in = x_mod * modN + y_mod

            for k in range(256):
                if k % modN != key_class:
                    continue
                z, _ = block_func(x, y, k)
                z_mod = z % modN
                table[idx_in, z_mod] += 1
                counts[idx_in] += 1

    for i in range(len(counts)):
        if counts[i] > 0:
            table[i, :] /= counts[i]

    return table

def write_table(file, table, modN, name, key_class):
    col_width = 9
    file.write(f"\n=== {name} (mod {modN}), ключи k ≡ {key_class} mod {modN} ===\n")
    header = " " * 6 + "".join(f"{z}".center(col_width) for z in range(modN))
    file.write(header + "\n")
    for row_idx, row in enumerate(table):
        x_class = row_idx // modN
        y_class = row_idx % modN
        row_str = f"({x_class},{y_class}) ".ljust(6)
        row_str += "".join(f"{v:>{col_width}.4f}" for v in row)
        file.write(row_str + "\n")

if __name__ == "__main__":
    output_dir = "E:/modN_key_tables"
    os.makedirs(output_dir, exist_ok=True)

    for modN in range(12, 256):
        with open(os.path.join(output_dir, f"modN_{modN}.txt"), "w", encoding="utf-8") as f:
            print(f"🚀 Обработка modN = {modN}")
            for key_class in range(modN):
                # A_k таблица
                table_A = build_transition_table_key_class(A_k, modN, key_class)
                write_table(f, table_A, modN, name="A_k", key_class=key_class)

                # B_k таблица
                table_B = build_transition_table_key_class(B_k, modN, key_class)
                write_table(f, table_B, modN, name="B_k", key_class=key_class)

    print("\n✅ Все таблицы успешно записаны в папку 'E:/modN_keyclass_tables'")
