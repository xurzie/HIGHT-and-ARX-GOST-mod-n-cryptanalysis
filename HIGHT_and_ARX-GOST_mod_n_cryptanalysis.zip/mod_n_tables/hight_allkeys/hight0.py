import numpy as np

def rol8(x, r):
    return ((x << r) | (x >> (8 - r))) & 0xFF

def F0(x):
    return rol8(x, 1) ^ rol8(x, 2) ^ rol8(x, 7)

def F1(x):
    return rol8(x, 3) ^ rol8(x, 4) ^ rol8(x, 6)

def A_k(x, y, k):
    return ((x + F0(y ^ k)) % 256, y)

def B_k(x, y, k):
    return (x ^ F1((y + k) % 256), y)

def build_transition_table_all_keys(block_func, modN):
    table = np.zeros( (modN * modN, modN), dtype=np.float64 )
    counts = np.zeros( modN * modN, dtype=np.int64 )

    for x in range(256):
        for y in range(256):
            x_mod = x % modN
            y_mod = y % modN
            idx_in = x_mod * modN + y_mod

            for k in range(256):
                z, _ = block_func(x, y, k)
                z_mod = z % modN

                table[idx_in, z_mod] += 1
                counts[idx_in] += 1

    for i in range(len(counts)):
        if counts[i] > 0:
            table[i, :] /= counts[i]

    return table

def write_table_to_file(file, table, modN, name):
    col_width = 9
    file.write(f"\n=== Таблица переходов для {name} (mod {modN}), все k ===\n")
    header = " " * 6 + "".join(f"{z}".center(col_width) for z in range(modN))
    file.write(header + "\n")
    for row_idx, row in enumerate(table):
        x_class = row_idx // modN
        y_class = row_idx % modN
        row_str = f"({x_class},{y_class}) ".ljust(6)
        row_str += "".join(f"{v:>{col_width}.4f}" for v in row)
        file.write(row_str + "\n")

# --- Основной запуск ---

if __name__ == "__main__":
    output_file = "hight_Ak_Bk_modN_all_keys_tables.txt"
    with open(output_file, "w", encoding="utf-8") as f:
        for modN in range(3, 256):
            print(f"Обработка модуль modN = {modN}")

            # Таблица для A_k
            table_A = build_transition_table_all_keys(A_k, modN)
            write_table_to_file(f, table_A, modN, name="A_k")

            # Таблица для B_k
            table_B = build_transition_table_all_keys(B_k, modN)
            write_table_to_file(f, table_B, modN, name="B_k")

    print(f"\nВсе таблицы успешно записаны в файл '{output_file}'!")
